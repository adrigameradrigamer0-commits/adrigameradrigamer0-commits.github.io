ADriGamer Support — publicación en GitHub Pages

IMPORTANTE: en este ZIP, index.html está directamente en la raíz.

1. Descarga y descomprime este ZIP en tu ordenador.
2. Abre el repositorio de GitHub que publica tu página.
3. Pulsa Add file > Upload files.
4. Sube TODOS los archivos y carpetas que están dentro de esta carpeta descomprimida.
   No subas la carpeta contenedora como una carpeta única.
5. Confirma con Commit changes en la rama main.
6. En Settings > Pages, selecciona Deploy from a branch, branch main y carpeta /(root).
   Guarda los cambios. Si ya usas otra fuente de publicación, verifica que index.html
   esté en el nivel superior de esa fuente.
7. Espera a que termine el despliegue y abre la URL de GitHub Pages.

La página de inicio es index.html. La página del formulario está en
bug/AdriGamer_MC/index.html, así que su ruta es /bug/AdriGamer_MC?bug.

El dominio personalizado adrigamerbooks.com aún requiere configurar DNS y Pages.
El reenvío de formularios está configurado para FormSubmit, pero requiere la
confirmación inicial del buzón adrigameradrigamer0@gmail.com y una prueba real.
