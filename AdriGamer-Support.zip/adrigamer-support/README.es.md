# AdriGamer Support — paquete web

Este ZIP contiene una web estática en español para el centro de soporte de AdriGamer_MC.

## Contenido

- `index.html`: portada del centro de soporte.
- `bug/AdriGamer_MC/index.html`: formulario de reportes. La ruta prevista es `/bug/AdriGamer_MC?bug`.
- `gracias.html`: página de confirmación tras enviar el formulario.
- `assets/styles.css`: estilos adaptables a móvil y escritorio.
- `assets/app.js`: contador de caracteres y validación del archivo adjunto.
- `assets/favicon.svg`: icono del sitio.

## Correo de recepción

El formulario está configurado para enviar los reportes a `adrigameradrigamer0@gmail.com` mediante FormSubmit (`formsubmit.co`). El formulario incluye edición Java/Bedrock/ambos, tipo de error, nombre del addon o paquete (texto libre), descripción, captura opcional y correo de contacto opcional.

**Activación necesaria:** la primera vez que se envíe un reporte, FormSubmit enviará un correo de activación a `adrigameradrigamer0@gmail.com`. Abre ese mensaje y pulsa el enlace de confirmación. Hasta completar ese paso no debe darse por verificado el envío. Después, realiza un reporte de prueba y comprueba la bandeja de entrada y spam.

La documentación oficial de FormSubmit describe el endpoint por correo, los campos `_subject`, `_template`, `_next` y la carga de archivos: https://formsubmit.co/documentation

## Publicar la web

1. Descomprime este ZIP.
2. Sube el contenido de la carpeta `adrigamer-support` a un alojamiento web estático (no subas la carpeta contenedora adicional si el panel te pide la carpeta raíz del sitio).
3. Configura en el proveedor del dominio los registros DNS que indique tu alojamiento para `adrigamerbooks.com` y `www.adrigamerbooks.com`.
4. Comprueba la portada y la ruta `https://www.adrigamerbooks.com/bug/AdriGamer_MC?bug`.
5. Envía un reporte de prueba y completa la activación de FormSubmit.

La ruta usa una carpeta real `bug/AdriGamer_MC/` con `index.html`. El parámetro `?bug` no requiere configuración especial en el servidor.

## Importante

- Este ZIP es un paquete estático nuevo preparado a partir de los requisitos escritos en la conversación. No es una exportación del proyecto original de Lovable, porque no se pudo acceder al contenido privado de su vista previa.
- El dominio no queda conectado por descargar o descomprimir el ZIP. La conexión DNS y la publicación deben hacerse en el proveedor de alojamiento/dominio.
- La recepción por correo depende de completar la activación inicial de FormSubmit y probar el formulario publicado.
- El adjunto admite JPG, PNG o WebP de hasta 10 MB.
