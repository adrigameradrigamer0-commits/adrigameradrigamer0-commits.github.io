(() => {
  const form = document.querySelector('.report-form');
  if (!form) return;

  const description = document.getElementById('description');
  const charCount = document.getElementById('char-count');
  const fileInput = document.getElementById('attachment');

  if (description && charCount) {
    const updateCount = () => { charCount.textContent = `${description.value.length} / 5000`; };
    description.addEventListener('input', updateCount);
    updateCount();
  }

  form.addEventListener('submit', (event) => {
    if (fileInput && fileInput.files && fileInput.files.length) {
      const file = fileInput.files[0];
      const allowed = ['image/jpeg', 'image/png', 'image/webp'];
      const maxBytes = 10 * 1024 * 1024;
      if (!allowed.includes(file.type)) {
        event.preventDefault();
        fileInput.setCustomValidity('Adjunta una imagen JPG, PNG o WebP.');
        fileInput.reportValidity();
        fileInput.setCustomValidity('');
        return;
      }
      if (file.size > maxBytes) {
        event.preventDefault();
        fileInput.setCustomValidity('La imagen supera el límite de 10 MB.');
        fileInput.reportValidity();
        fileInput.setCustomValidity('');
        return;
      }
    }
  });
})();
